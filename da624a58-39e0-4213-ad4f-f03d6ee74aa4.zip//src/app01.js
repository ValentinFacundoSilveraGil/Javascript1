document.write("<h1>Bienvenido a la página de Java script</h1>");
var nom = prompt("Ingresa tu nombre");
document.write(
  "Hola " + nom + " es tu primer contacto con la programación Java script"
);
